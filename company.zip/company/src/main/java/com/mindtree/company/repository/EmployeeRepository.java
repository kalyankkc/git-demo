package com.mindtree.company.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mindtree.company.entity.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

}
